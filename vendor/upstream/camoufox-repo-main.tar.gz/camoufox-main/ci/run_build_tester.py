#!/usr/bin/env python3
"""build-tester gate: the raw binary, 8 fingerprint profiles, graded per check.

Grades per individual check rather than per profile, so the evidence carries
~hundreds of stable identities and a baseline comparison can say "this exact
check passed on the last release and does not now" instead of "the grade dropped
from A to B". (Nothing in this repository holds that baseline; the auto-update
harness does. Here the identities make a failure legible.)

Run:
    python3 -m ci.run_build_tester --binary /path/to/camoufox-bin
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional

from . import results as evidence
from ._util import CI_DIR, RESULTS_DIR, REPO_ROOT, WORK_DIR, read_json, run

BUILD_TESTER = REPO_ROOT / "build-tester"
CONFIG_PATH = CI_DIR / "build-tester.yml"

# Cross-profile uniqueness, split by what each slot actually promises. Treating
# them alike made the gate fail a run that scored 1054/1054: it counted three
# macOS contexts all reporting "MacIntel" as three collisions, which is the
# correct answer to a question nobody asked.
#
# Values Camoufox derives per context. Two contexts sharing one is the leak
# this whole suite exists to catch, so a single collision here is fatal.
_MUST_VARY = ("uniqueAudio", "uniqueTimezones")

# Values that follow the device rather than the context. fonts, screens, voices
# and WebGL are drawn from a pool of real devices, and three draws from a pool
# of a dozen collide regularly -- the birthday paradox, not a leak. The canvas
# is rendered, not noised (ci/tribal-rules.yml: canvas-is-not-noised), so it
# follows the fonts and GPU the same way. Counted and reported, never fatal.
_MAY_COLLIDE = ("uniqueCanvas", "uniqueFonts", "uniqueScreens", "uniqueVoices", "uniqueWebGL")

# Properties of the operating system. Every macOS context reports MacIntel and
# every Linux one reports Linux x86_64, because that is what those systems
# report. Here a collision is the correct outcome and *variation* would be the
# bug, so it is asserted in the opposite direction.
_MUST_MATCH = ("uniquePlatforms",)


# A renderer string that names a software rasteriser. The page-side
# headlessDetection/noSwiftShader check flags these, because a browser reporting
# one is usually a headless browser on a machine with no GPU.
_SOFTWARE_RENDERERS = ("swiftshader", "llvmpipe", "software")


def _is_software_renderer(value: Optional[str]) -> bool:
    low = (value or "").lower()
    return any(token in low for token in _SOFTWARE_RENDERERS)


def check_passed(meta: dict, section: str, category: str, check: str, payload: dict) -> bool:
    """Did this check pass, judged against what the profile actually asked for?

    Almost always just `payload["passed"]`. The exception is
    extended/headlessDetection/noSwiftShader, which reads the WebGL renderer and
    fails on a software rasteriser -- a sound headless signal in general, and the
    wrong question to ask here. Camoufox's own fingerprint pool contains real
    Linux machines whose renderer IS llvmpipe (`fingerprint-presets-v150.json`
    ships "llvmpipe, or similar"), so when such a profile is drawn, reporting
    llvmpipe is the spoof working exactly as instructed -- and reporting anything
    else would be the bug. Grading it as a failure made this gate fail at random,
    depending on which presets that run's `generate_context_fingerprint()` drew.

    So the check fails only when the browser reports a software renderer the
    profile did not ask for, which is the case that would really mean the WebGL
    spoof had fallen through to the host.
    """
    passed = bool(payload.get("passed"))
    if passed:
        return True
    if (section, category, check) == ("extended", "headlessDetection", "noSwiftShader"):
        return _is_software_renderer(meta.get("webglRenderer"))
    return False


def flatten(full: dict) -> Dict[str, str]:
    """The whole result tree -> {check_id: pass|fail}."""
    tests: Dict[str, str] = {}
    for profile in full.get("profiles") or []:
        meta = profile.get("profile") or {}
        # Identify by os+mode+index, never by the display name, which carries a
        # random letter suffix and would churn every run.
        slot = f"{meta.get('os', '?')}-{meta.get('mode', '?')}-{meta.get('index', profile.get('index', 0))}"
        results = profile.get("results") or {}
        if profile.get("error"):
            tests[f"{slot}/launch"] = evidence.ERROR
            continue
        tests[f"{slot}/launch"] = evidence.PASS

        for section in ("core", "extended", "workers", "selfDestruct"):
            categories = results.get(section) or {}
            if not isinstance(categories, dict):
                continue
            for category, checks in categories.items():
                if not isinstance(checks, dict):
                    continue
                for check, payload in checks.items():
                    if not isinstance(payload, dict) or not isinstance(payload.get("passed"), bool):
                        continue
                    tid = f"{slot}/{section}/{category}/{check}"
                    ok = check_passed(meta, section, category, check, payload)
                    tests[tid] = evidence.PASS if ok else evidence.FAIL

        webrtc = results.get("webrtc") or {}
        if webrtc:
            tests[f"{slot}/webrtc"] = evidence.PASS if webrtc.get("passed") else evidence.FAIL
        stability = results.get("stability") or {}
        if stability:
            tests[f"{slot}/stability"] = evidence.PASS if stability.get("stable") else evidence.FAIL
        for match in profile.get("matchResults") or []:
            name = match.get("name") or match.get("key") or "match"
            tests[f"{slot}/match/{name}"] = evidence.PASS if match.get("passed") else evidence.FAIL
    return tests


def category_failures(full: dict, required: List[str]) -> Dict[str, int]:
    """Failing check counts for the categories policy insists must be clean."""
    wanted = {c.lower() for c in required}
    out: Dict[str, int] = {}
    for profile in full.get("profiles") or []:
        meta = profile.get("profile") or {}
        results = profile.get("results") or {}
        for section in ("core", "extended", "workers", "selfDestruct"):
            for category, checks in (results.get(section) or {}).items():
                if category.lower() not in wanted or not isinstance(checks, dict):
                    continue
                for check, payload in checks.items():
                    if not isinstance(payload, dict) or payload.get("passed") is not False:
                        continue
                    # Same judgement flatten() makes, so the required-category
                    # gate and the per-check evidence cannot disagree.
                    if not check_passed(meta, section, category, check, payload):
                        out[category] = out.get(category, 0) + 1
    return out


def uniqueness(full: dict) -> Dict[str, List[str]]:
    """Sort the cross-profile slots into leaks, noise, and things not measured.

    Returns {"leaks": [...], "noise": [...], "absent": [...], "not_constant": [...]}.
    Only `leaks` and `not_constant` should fail a build.
    """
    out: Dict[str, List[str]] = {
        "leaks": [], "noise": [], "absent": [], "not_constant": []
    }

    for group, stats in (full.get("crossProfile") or {}).items():
        total = stats.get("total") or 0
        if total < 2:
            continue

        def describe(key: str) -> str:
            return f"{group}.{key} ({stats.get(key)}/{total} distinct)"

        for key in _MUST_VARY + _MAY_COLLIDE:
            value = stats.get(key)
            if not isinstance(value, int):
                continue
            if value == 0:
                # Nothing was gathered -- no speech voices under a headless
                # session, say. "Zero distinct" is absence, and counting it as a
                # collision reports a leak where there is no data at all.
                out["absent"].append(describe(key))
            elif value < total:
                out["leaks" if key in _MUST_VARY else "noise"].append(describe(key))

        for key in _MUST_MATCH:
            value = stats.get(key)
            if isinstance(value, int) and value > 1:
                out["not_constant"].append(describe(key))

    return out


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path)
    parser.add_argument("--evidence-dir", type=Path, default=RESULTS_DIR)
    parser.add_argument("--timeout", type=int, default=3600)
    args = parser.parse_args(argv)

    import yaml

    with open(CONFIG_PATH, encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh) or {}

    from ._pytest import require_binary

    result = evidence.GateResult(gate="build_tester")
    out_json = WORK_DIR / "build-tester-result.json"

    try:
        binary = args.binary or require_binary()
    except FileNotFoundError as exc:
        result.note(str(exc))
        result.finish(evidence.ERROR).save(args.evidence_dir)
        return 1

    proc = run(
        [
            sys.executable, "scripts/run_tests.py", str(binary),
            "--profile-count", str(cfg.get("profile_count", 8)),
            "--json", str(out_json),
            "--no-cert",
        ],
        cwd=BUILD_TESTER,
        timeout=args.timeout,
        tee=True,
        capture=False,
    )

    if not out_json.exists():
        result.note(
            f"build-tester exited {proc.code} without writing {out_json.name}. "
            "It crashed before grading; treat this as a failure, not a flake."
        )
        result.finish(evidence.ERROR).save(args.evidence_dir)
        return 1

    full = read_json(out_json)
    result.tests = flatten(full)
    result.artifacts.append(out_json.name)
    result.metrics.update(
        overall_grade=full.get("overallGrade"),
        total_passed=full.get("totalPassed"),
        total_checks=full.get("totalChecks"),
        cross_profile=full.get("crossProfile"),
        exit_code=proc.code,
    )

    status = evidence.PASS
    # Rules that hold regardless of what the baseline looked like. verify.py
    # fails the run on these even when the previous release was equally dirty.
    violations: List[str] = []

    failures = category_failures(full, cfg.get("required_categories") or [])
    if failures:
        pretty = ", ".join(f"{k}: {v}" for k, v in sorted(failures.items()))
        result.note(f"categories policy requires clean have failing checks -- {pretty}")
        violations.append(f"categories that must be clean have failing checks: {pretty}")
        status = evidence.FAIL

    slots = uniqueness(full)
    allowed = int(cfg.get("allow_uniqueness_collisions", 0))
    result.metrics["uniqueness"] = slots

    if slots["noise"]:
        result.note(
            f"{len(slots['noise'])} device-level collision(s), not gated: "
            + ", ".join(slots["noise"])
        )
    if slots["absent"]:
        result.note(
            f"{len(slots['absent'])} slot(s) collected nothing: " + ", ".join(slots["absent"])
        )

    if slots["leaks"]:
        result.note(
            f"{len(slots['leaks'])} per-context value(s) shared between contexts: "
            + ", ".join(slots["leaks"])
            + f" (policy tolerates {allowed})"
        )
        if len(slots["leaks"]) > allowed:
            violations.append(
                "per-context values shared between contexts, which is the leak this suite "
                "exists to catch: " + ", ".join(slots["leaks"])
            )
            status = evidence.FAIL

    if slots["not_constant"]:
        result.note("OS-constant value varied between contexts: " + ", ".join(slots["not_constant"]))
        violations.append(
            "a value that is a property of the operating system differed between contexts of "
            "the same OS: " + ", ".join(slots["not_constant"])
        )
        status = evidence.FAIL

    result.metrics["policy_violations"] = violations

    result.note(
        f"grade {full.get('overallGrade')}, {full.get('totalPassed')}/{full.get('totalChecks')} checks, "
        f"{len(result.tests)} identities recorded"
    )
    result.finish(status).save(args.evidence_dir)
    return 0 if status == evidence.PASS else 1


if __name__ == "__main__":
    sys.exit(main())
