#!/usr/bin/env python3
"""Stealth gate: drive the private sundial suite and bring back numbers only.

Sundial is a private detection suite. Its value is that the vectors it probes
are not public, so **nothing identifying a vector may ever leave this module**:
not a name, not a description, not a measured value, not the test's source. This
repository is public, and an evidence file or a pull-request comment is
permanent. Everything downstream of `_redact()` is counts and opaque ids.

The opaque id is `HMAC(salt, vector_key)`. That is enough to notice "the vector
that passed last release is failing now", which is the only thing the gate
needs, and it is not enough to learn what the vector was.

Scope: only categories Camoufox actually claims to implement are gated
(`ci/sundial.yml: gated_categories`). Cross-OS rendering parity, for one, is
measured and reported but never fails a build -- Camoufox does not claim
byte-identical emulation of another platform's rasterizer.

How it runs:
  1. Form-login to sundial, keep the `sundial_session` cookie.
  2. Start a loopback collector.
  3. Launch the built binary, seed the cookie, open `?auto=1&post=<collector>`.
     Sundial runs its scan on load and POSTs `window.fullReport` back.
  4. Redact, score, write evidence.

Run:
    python3 -m ci.run_sundial --binary /path/to/camoufox-bin
    python3 -m ci.run_sundial waive --key '<vector key>' --reason '...'
"""

from __future__ import annotations

import argparse
import asyncio
import http.server
import json
import os
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from . import results as evidence
from ._util import CI_DIR, RESULTS_DIR, WORK_DIR, log, opaque_id, run

CONFIG_PATH = CI_DIR / "sundial.yml"
COOKIE_NAME = "sundial_session"
# The account CI logs in as. `guest` is the least-privileged role the deployment
# actually has (sundial 0.5.0): its middleware refuses `guest` the private-vector
# bundle outright, so the definitions this repository must never see are not
# served to this session at all.
#
# Two guarantees keep a vector out of a public log, and it is worth being precise
# about which is which, because only one of them is enforced by the server:
#
#   server-side  `guest` is answered with an empty stub for vectors-private.js
#                (_middleware.js gates that path on the role). `admin` and
#                `private` are not -- so the gate verifies the session's role
#                against /__auth/me and refuses to scan under either of them,
#                rather than trusting that the right key was configured.
#   client-side  this gate only ever requests `/?auto=1&score=1`, and redact()
#                refuses to process anything that is not a score payload, so a
#                deployment that ignored `score=1` fails the run instead of
#                folding a report down and carrying on.
#
# The stricter option is sundial's score-only `ci` role, which is refused
# anything but `/?auto=1&score=1` server-side and so cannot retrieve a report
# even if this credential leaks. That role is not in sundial's master branch and
# is therefore not deployed; when it lands, set SUNDIAL_USERNAME=ci and the
# server-side half of the guarantee gets stronger with no change here.
DEFAULT_USERNAME = "guest"
DEFAULT_URL = "https://sundial.daijro.dev"

# Report fields that may describe a private vector. Dropped without exception.
_FORBIDDEN_FIELDS = (
    "name", "brief", "src", "source", "value", "expect", "requires",
    "key", "id", "cat", "elapsedMs", "entropy",
)

# The complete set of keys allowed to leave this module. A whitelist, checked at
# runtime, because a blacklist only stops the leaks somebody already thought of:
# add a field to redact() and forget to think about it, and a blacklist ships it.
# This fails the run instead.
#
# There are deliberately no per-vector rows here, not even opaque ones. An HMAC
# does not name a vector, but a map of them is still per-vector data: it says how
# many distinct checks fail and lets a reader follow the same id across releases.
# The instruction is a score, so this is a score.
_PUBLISHABLE = frozenset({
    "grade",              # a letter
    "checks_total",       # how many in-scope checks were scored
    "checks_passed",
    "pass_rate",
    "out_of_scope_failed",  # a single count, no attribution
    "unknown_category_checks",  # ditto -- how many, never which
    "sundial_role",  # which role CI authenticated as; names an account, not a vector
    "cross_os_total",     # host-OS detectors: measured, never gated
    "cross_os_passed",
    "score_mode",         # did sundial answer in score mode? a protocol fact
    "os",                 # which profile it was measured under; we chose it
    "sundial_version",
    "schema_version",
    "policy_violations",  # our own strings, not sundial's
})


def _assert_publishable(metrics: Dict[str, Any]) -> Dict[str, Any]:
    """Refuse to hand back anything not on the whitelist."""
    extra = set(metrics) - _PUBLISHABLE
    if extra:
        raise RuntimeError(
            f"the stealth gate tried to publish {sorted(extra)}, which is not on the "
            "whitelist in ci/run_sundial.py. Sundial's vectors are private and this "
            "repository is public; add the key to _PUBLISHABLE only after deciding it "
            "is a score and not a metric."
        )
    return metrics


# ---------------------------------------------------------------------------
# auth
# ---------------------------------------------------------------------------


class SundialUnavailable(RuntimeError):
    """The deployment could not be reached -- not a verdict about the browser.

    Sundial is a separate service on a separate host. When it is down, or DNS
    fails, or the edge answers 502 for a minute, the browser under test has not
    been measured at all -- and failing the merge gate for that makes an
    unrelated outage into a block on every pull request in the repository.

    So this is raised for transport-level failures only, and `gate()` turns it
    into a SKIP that `ci/summarize.py` is told to tolerate. Everything that is
    an actual answer from sundial -- a rejected credential, a role that would be
    served the vectors, a full report where a score was asked for, a pass rate
    under the floor -- stays a hard failure, because those are statements about
    this repository's configuration or this browser, and neither gets to be
    waved through by an exception type.
    """


def _unavailable_reason(exc: BaseException) -> Optional[str]:
    """Why this exception means "sundial is down", or None if it does not.

    An HTTPError IS a reply, so most of them are real answers and must fail:
    401 is a bad credential, 403 is the edge refusing us. Only 5xx (the origin
    is broken) and 429 (it is refusing to serve anyone right now) are outages.
    Anything that is a URLError but not an HTTPError never reached a server at
    all -- DNS, refused connection, TLS, timeout.
    """
    if isinstance(exc, urllib.error.HTTPError):
        if exc.code >= 500:
            return f"sundial returned HTTP {exc.code}"
        if exc.code == 429:
            return "sundial is rate-limiting every request (HTTP 429)"
        return None
    if isinstance(exc, urllib.error.URLError):
        return f"sundial could not be reached ({exc.reason})"
    if isinstance(exc, (TimeoutError, ConnectionError)):
        return f"sundial could not be reached ({type(exc).__name__}: {exc})"
    return None


# Cloudflare sits in front of sundial and refuses document requests carrying a
# non-browser User-Agent, before they reach sundial at all. Measured against the
# live host: `/automated?key=<bogus>` answers **401** with a browser User-Agent
# and **403** with urllib's default.
#
# That matters here because the token route below is exactly such a request, and
# it is the route this repository's credential actually uses. Sent with the old
# `User-Agent: camoufox-harness` it would have been refused by the edge, and the
# 403 would have read like a permissions problem rather than a bot filter.
#
# On every request, not just the first: a client that authenticates with browser
# headers and then fetches with urllib's defaults logs in successfully and gets
# a confusing 403 on the very next hop.
_BROWSER_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Upgrade-Insecure-Requests": "1",
}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Both auth routes answer 303 + Set-Cookie; following it hides the cookie."""

    def redirect_request(self, *_args, **_kwargs):  # noqa: D102
        return None


def _session_cookie(headers) -> Optional[str]:  # noqa: ANN001
    for raw in headers.get_all("Set-Cookie") or []:
        if raw.startswith(COOKIE_NAME + "="):
            value = raw.split(";", 1)[0][len(COOKIE_NAME) + 1 :]
            if value:
                return value
    return None


def login_with_key(base_url: str, key: str, *, timeout: int = 30) -> str:
    """Token login: `GET /automated?key=` mints the session cookie.

    This is the route the credential in CI is actually for -- sundial's
    `make pages-automation-keys` mints report-URL keys, and a key presented here
    resolves to the `guest` role. Tried before the form because it needs no
    username, so there is no second secret to keep in step with whatever
    `GUEST_USER` was set to.
    """
    url = base_url.rstrip("/") + "/automated?key=" + urllib.parse.quote(key, safe="")
    req = urllib.request.Request(url, headers=_BROWSER_HEADERS)
    opener = urllib.request.build_opener(_NoRedirect)
    try:
        resp = opener.open(req, timeout=timeout)
        status, headers = resp.status, resp.headers
    except urllib.error.HTTPError as exc:
        outage = _unavailable_reason(exc)
        if outage:
            raise SundialUnavailable(outage) from None
        status, headers = exc.code, exc.headers
    except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
        # HTTPError is a URLError, and is handled above; reaching here means no
        # server answered at all.
        raise SundialUnavailable(_unavailable_reason(exc) or str(exc)) from None
    cookie = _session_cookie(headers)
    if cookie:
        log("sundial auth OK (automation key)")
        return cookie
    raise RuntimeError(f"the automation key route returned {status} and no session cookie")


def login(base_url: str, username: str, password: str, *, timeout: int = 30) -> str:
    """Form-login and return the session cookie value.

    The endpoint answers 303 + Set-Cookie on success and 401 + the login page on
    failure, so a redirect handler would hide the result; handle it manually.
    """
    body = urllib.parse.urlencode({"username": username, "password": password}).encode()
    req = urllib.request.Request(
        base_url.rstrip("/") + "/__auth/login",
        data=body,
        method="POST",
        headers={
            **_BROWSER_HEADERS,
            "Content-Type": "application/x-www-form-urlencoded",
        },
    )

    opener = urllib.request.build_opener(_NoRedirect)
    try:
        resp = opener.open(req, timeout=timeout)
        status, headers = resp.status, resp.headers
    except urllib.error.HTTPError as exc:
        status, headers = exc.code, exc.headers
        if status == 401:
            raise RuntimeError(
                "sundial rejected the credentials. Check SUNDIAL_USERNAME and "
                "SUNDIAL_AUTOMATION_KEY."
            ) from None
        outage = _unavailable_reason(exc)
        if outage:
            raise SundialUnavailable(outage) from None
        if status != 303:
            raise RuntimeError(f"sundial login returned {status}") from None
    except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
        raise SundialUnavailable(_unavailable_reason(exc) or str(exc)) from None

    cookie = _session_cookie(headers)
    if cookie:
        log("sundial login OK (form)")
        return cookie
    raise RuntimeError("sundial login succeeded but returned no session cookie")


def scrub(text: str, secret: str) -> str:
    """Remove a secret from text that is about to be published.

    Whatever goes into result.note() reaches the results artifact and the pull
    request comment, and an exception raised deep inside urllib can carry the
    URL that produced it -- which, for the token route, is the credential. So
    nothing built from an exception is published until it has been through here.
    Both the raw secret and its percent-encoded form, because the URL holds the
    latter.
    """
    if not secret:
        return text
    for form in (secret, urllib.parse.quote(secret, safe="")):
        if form:
            text = text.replace(form, "<redacted>")
    return text


# Roles sundial will not serve the private-vector bundle to. Everything rests on
# the session being one of these: `redact()` controls what this repository
# *publishes*, but only the role controls what the browser is *given*, and a
# public runner holding the vectors at all is the thing being prevented.
#
# `guest` is what an AUTOMATION_GUEST_KEY resolves to. `ci` is sundial's
# score-only role, for when it lands. `private` and `admin` both load the
# vectors and must never be what CI ends up as -- which is a live possibility,
# not a hypothetical: /automated?key= resolves to `private` when handed the
# private key, and the two keys are indistinguishable by looking at them.
ROLES_WITHOUT_VECTORS = frozenset({"guest", "ci"})


def session_role(base_url: str, cookie: str, *, timeout: int = 30) -> Optional[str]:
    """The role this session actually has, per sundial's own /__auth/me.

    Returns None if the endpoint is absent or unreadable -- an older deployment
    may not have it, and the caller decides what to do about that.
    """
    req = urllib.request.Request(
        base_url.rstrip("/") + "/__auth/me",
        headers={**_BROWSER_HEADERS, "Accept": "application/json", "Cookie": f"{COOKIE_NAME}={cookie}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
            if resp.status != 200:
                return None
            return (json.loads(resp.read().decode("utf-8")) or {}).get("role")
    except Exception:  # noqa: BLE001 -- absence is not an error here
        return None


def assert_role_cannot_read_vectors(base_url: str, cookie: str, *, timeout: int = 30) -> str:
    """Refuse to scan under a role that would be handed the private vectors."""
    role = session_role(base_url, cookie, timeout=timeout)
    if role is None:
        raise RuntimeError(
            "sundial did not say what role this session has (/__auth/me returned nothing "
            "usable), so it cannot be confirmed that the browser will be refused the "
            "private vectors. Refusing to scan: the alternative is loading them onto a "
            "public runner on the assumption that the credential was the right one."
        )
    if role not in ROLES_WITHOUT_VECTORS:
        raise RuntimeError(
            f"this credential authenticates as the {role!r} role, which sundial serves the "
            f"private vectors to. CI must use one of {sorted(ROLES_WITHOUT_VECTORS)} -- set "
            "SUNDIAL_AUTOMATION_KEY to the guest automation key (`make pages-automation-keys`), "
            "not the private one. Refusing to scan."
        )
    log(f"sundial session role is {role!r}; the private vectors are not served to it")
    return role


def authenticate(base_url: str, username: str, secret: str, *, timeout: int = 30) -> str:
    """Get a session cookie, whichever shape the stored credential is.

    SUNDIAL_AUTOMATION_KEY has been both things over this repository's life: an
    automation key for `/automated?key=`, and a password for the login form. The
    two are indistinguishable by looking at them, and which one a given
    repository holds is not something this code can know -- so try the key route
    first (it needs no username) and fall back to the form. The only cost when
    the secret is a password is one extra request that 401s.
    """
    errors = []
    # Only if BOTH routes failed for transport reasons is the deployment down.
    # One route 401ing is an answer -- it says the secret is the other shape --
    # so a single real reply is enough to know sundial is up, and a failure
    # after that is this repository's problem to fix rather than an outage.
    outages = []
    try:
        return login_with_key(base_url, secret, timeout=timeout)
    except Exception as exc:  # noqa: BLE001 -- reported below if the form fails too
        detail = scrub(str(exc), secret)
        errors.append(f"automation key: {detail}")
        if isinstance(exc, SundialUnavailable):
            outages.append(detail)
        log(f"automation-key login did not take ({detail}); trying the form", level="WARN")
    try:
        return login(base_url, username, secret, timeout=timeout)
    except Exception as exc:  # noqa: BLE001
        errors.append(f"form login as {username!r}: {scrub(str(exc), secret)}")
        if isinstance(exc, SundialUnavailable):
            outages.append(scrub(str(exc), secret))

    if len(outages) == len(errors):
        raise SundialUnavailable(
            scrub(
                "sundial is unreachable; neither auth route got an answer:\n  "
                + "\n  ".join(errors),
                secret,
            )
        )
    raise RuntimeError(
        scrub(
            "could not authenticate to sundial. Both routes were tried:\n  "
            + "\n  ".join(errors),
            secret,
        )
        + "\nSUNDIAL_AUTOMATION_KEY must be either an automation key from "
        "`make pages-automation-keys` or the password for the account named by "
        "SUNDIAL_USERNAME (default 'guest')."
    )


# ---------------------------------------------------------------------------
# collector
# ---------------------------------------------------------------------------


class _Collector:
    """Loopback endpoint that receives the one POST sundial makes."""

    def __init__(self) -> None:
        self.payload: Optional[dict] = None
        self._event = threading.Event()
        outer = self

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_POST(self) -> None:  # noqa: N802
                length = int(self.headers.get("Content-Length", "0"))
                raw = self.rfile.read(length).decode("utf-8", "replace")
                try:
                    outer.payload = json.loads(raw)
                except json.JSONDecodeError:
                    outer.payload = {"_parse_error": raw[:500]}
                self.send_response(204)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                outer._event.set()

            def do_OPTIONS(self) -> None:  # noqa: N802
                self.send_response(204)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Headers", "*")
                self.end_headers()

            def log_message(self, *_args) -> None:  # keep the run log readable
                return

        self._server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.port = self._server.server_address[1]
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)

    def __enter__(self) -> "_Collector":
        self._thread.start()
        log(f"collector listening on 127.0.0.1:{self.port}")
        return self

    def __exit__(self, *_exc) -> None:
        self._server.shutdown()
        self._server.server_close()

    def wait(self, timeout: float) -> Optional[dict]:
        self._event.wait(timeout)
        return self.payload


# ---------------------------------------------------------------------------
# redaction
# ---------------------------------------------------------------------------


def _iter_entries(report: dict) -> List[Tuple[str, str, str]]:
    """(vector_key, category, status) for every vector, public and private."""
    out: List[Tuple[str, str, str]] = []
    buckets = ("failures", "succeeded", "pending", "skipped")
    for scope in (report, report.get("private") or {}):
        if not isinstance(scope, dict):
            continue
        for bucket in buckets:
            grouped = scope.get(bucket)
            if not isinstance(grouped, dict):
                continue
            for category, entries in grouped.items():
                for entry in entries or []:
                    if not isinstance(entry, dict):
                        continue
                    key = entry.get("key") or entry.get("id") or ""
                    if not key:
                        continue
                    out.append((str(key), str(category or "Uncategorised"), str(entry.get("status", "pending"))))
    return out


_STATUS_MAP = {
    "pass": evidence.PASS,
    "fail": evidence.FAIL,
    "error": evidence.ERROR,
    "skipped": evidence.SKIP,
    "pending": evidence.SKIP,
}


def grade(pass_rate: float) -> str:
    """A single letter, which is the only stealth number that goes public."""
    for floor, letter in ((0.99, "A+"), (0.97, "A"), (0.94, "B"), (0.90, "C"), (0.80, "D")):
        if pass_rate >= floor:
            return letter
    return "F"


def _from_buckets(payload: dict, gated: List[str], ungated: List[str]) -> Dict[str, int]:
    """Fold sundial's score payload into the three numbers we publish.

    Buckets arrive keyed "<Category>|<class>". Category decides scope -- whether
    Camoufox claims that area at all -- and class decides whether a failure is
    the browser's fault or the machine's.

    A category in neither list is counted separately. sundial's taxonomy is nine
    top-level sections and ci/sundial.yml names all nine, so a tenth means
    sundial grew one and nobody decided whether Camoufox claims it. Folding that
    into "out of scope" would answer the question by default, in the direction
    that never fails a build -- a stealth blind spot that looks like a pass.
    """
    gated_set = {c.lower() for c in gated}
    known = gated_set | {c.lower() for c in ungated}
    scored = passed = 0
    out_of_scope_failed = 0
    unknown_scored = 0
    cross_total = cross_passed = 0

    for key, bucket in (payload.get("buckets") or {}).items():
        category, _, cls = str(key).partition("|")
        n_scored = int(bucket.get("scored", 0))
        n_passed = int(bucket.get("passed", 0))

        if cls == "crossOs":
            # Host-OS detectors read the machine underneath, not the disguise.
            # Camoufox does not claim byte-identical cross-OS emulation, so
            # these are reported and never gated -- counting them against the
            # score would be marking it down for a promise nobody made.
            cross_total += n_scored
            cross_passed += n_passed
            continue

        if category.lower() in gated_set:
            scored += n_scored
            passed += n_passed
        else:
            out_of_scope_failed += n_scored - n_passed
            if category.lower() not in known:
                unknown_scored += n_scored

    return {
        "scored": scored,
        "passed": passed,
        "out_of_scope_failed": out_of_scope_failed,
        "unknown_category_checks": unknown_scored,
        "cross_os_total": cross_total,
        "cross_os_passed": cross_passed,
    }


def explain_buckets(payload: dict, gated: List[str], ungated: List[str]) -> List[str]:
    """Per-category pass/fail lines from a score payload, for a local run.

    This is as far as score mode can take you. sundial's score answer carries
    buckets keyed "<Category>|<class>" holding two integers each -- there are no
    check names in it, and no opaque ids either, so "which five failed" is a
    question the payload cannot answer at any level of effort. What it can say
    is which category they are in, which is usually enough to know where to look.

    For the names you need a full report, which means a role sundial will serve
    one to and `--allow-full-report`. This never returns anything that goes into
    a result file; `_PUBLISHABLE` still governs what is published.
    """
    gated_set = {c.lower() for c in gated}
    known = gated_set | {c.lower() for c in ungated}

    rows: List[tuple] = []
    for key, bucket in sorted((payload.get("buckets") or {}).items()):
        category, _, cls = str(key).partition("|")
        scored = int(bucket.get("scored", 0))
        passed = int(bucket.get("passed", 0))
        if not scored:
            continue
        if cls == "crossOs":
            scope = "cross-OS (never gated)"
        elif category.lower() in gated_set:
            scope = "gated"
        elif category.lower() in known:
            scope = "out of scope"
        else:
            scope = "UNKNOWN CATEGORY -- decide whether Camoufox claims it"
        rows.append((scored - passed, category, cls or "-", passed, scored, scope))

    if not rows:
        return ["no buckets in the payload -- was this a score-mode answer?"]

    lines = ["", "per-category breakdown (local only, never published):"]
    width = max(len(r[1]) for r in rows)
    for failed, category, cls, passed, scored, scope in sorted(rows, reverse=True):
        mark = "FAIL" if failed else "  ok"
        lines.append(
            f"  {mark}  {category:<{width}}  {cls:<10} {passed:>4}/{scored:<4} "
            + (f"{failed} failing  [{scope}]" if failed else f"[{scope}]")
        )
    lines.append("")
    lines.append(
        "Score mode carries no check names, so this is the finest detail available "
        "to the credential CI uses. For the individual checks, re-run under a role "
        "sundial serves full reports to and pass --allow-full-report."
    )
    return lines


def redact(
    payload: dict,
    gated: List[str],
    ungated: List[str],
    *,
    os_name: str = "",
    require_score_mode: bool = True,
) -> Dict[str, Any]:
    """Turn sundial's response into a score, and nothing else.

    Two shapes arrive here. `mode: "score"` is the one to want: sundial has
    already aggregated, so no vector identity ever crossed the wire. A full
    report is **refused** unless `require_score_mode=False`, because the `ci`
    role this gate authenticates as cannot be served one -- so a report arriving
    means the run is misconfigured, and folding it down would hide that while
    the vectors sat in this process. The flag is for a deliberate local run
    under an account sundial does allow a report.

    Either way what leaves is a grade, how many in-scope checks were scored and
    passed, a count of out-of-scope failures, and the cross-OS tally kept
    separate. No names, no values, no categories, and no per-vector rows -- not
    even opaque ones, because a map of HMACs still publishes how many distinct
    checks fail and lets a reader follow one across releases.

    Regression detection is therefore per-score, not per-vector:
    `ci/sundial.yml` carries the floor (`min_pass_rate`), and the auto-update
    harness -- which is not in this repository -- adds a maximum allowed drop
    against its own baseline. For the per-vector view set
    SUNDIAL_REPORT_AGE_RECIPIENT and read the sealed report locally.
    """
    score_mode = payload.get("mode") == "score"
    if not score_mode and require_score_mode:
        # This gate asks for `/?auto=1&score=1` and nothing else, so a full
        # report cannot legitimately arrive here. If one does, the deployment
        # ignored `score=1` -- it predates score mode, or the request did not
        # reach the code that honours it. Either way the vectors are now in this
        # process, and the honest thing is to fail loudly rather than quietly
        # fold them down and carry on as though the guarantee had held.
        raise RuntimeError(
            "sundial answered with a full report, not a score. This gate only ever "
            "requests `?auto=1&score=1`, so the deployment did not honour it: check that "
            "sundial is at 0.5.0 or later (score mode landed in f136985). Refusing to "
            "process the payload. Pass --allow-full-report for a deliberate local run "
            "under an account that is allowed one."
        )
    if score_mode:
        counts = _from_buckets(payload, gated, ungated)
    else:
        # Legacy path: fold a full report down to the same numbers.
        gated_set = {c.lower() for c in gated}
        known = gated_set | {c.lower() for c in ungated}
        scored = passed = out_of_scope_failed = unknown_scored = 0
        for _key, category, status in _iter_entries(payload):
            outcome = _STATUS_MAP.get(status, evidence.SKIP)
            if outcome not in (evidence.PASS, evidence.FAIL, evidence.ERROR):
                continue
            if category.lower() in gated_set:
                scored += 1
                passed += outcome == evidence.PASS
            else:
                if outcome != evidence.PASS:
                    out_of_scope_failed += 1
                if category.lower() not in known:
                    unknown_scored += 1
        counts = {
            "scored": scored, "passed": passed,
            "out_of_scope_failed": out_of_scope_failed,
            "unknown_category_checks": unknown_scored,
            "cross_os_total": 0, "cross_os_passed": 0,
        }

    rate = round(counts["passed"] / counts["scored"], 4) if counts["scored"] else 0.0
    return _assert_publishable({
        "score_mode": score_mode,
        "grade": grade(rate),
        "checks_total": counts["scored"],
        "checks_passed": counts["passed"],
        "pass_rate": rate,
        "out_of_scope_failed": counts["out_of_scope_failed"],
        "unknown_category_checks": counts["unknown_category_checks"],
        "cross_os_total": counts["cross_os_total"],
        "cross_os_passed": counts["cross_os_passed"],
        "os": os_name,
        "sundial_version": payload.get("sundialVersion"),
        "schema_version": payload.get("schemaVersion"),
    })


# ---------------------------------------------------------------------------
# the scan
# ---------------------------------------------------------------------------


async def scan(
    *,
    binary: Path,
    base_url: str,
    cookie: str,
    os_name: str,
    headless: bool,
    timeout: float,
) -> dict:
    """Open sundial in the built browser and collect the report it posts back."""
    from camoufox.async_api import AsyncCamoufox

    host = urllib.parse.urlparse(base_url).hostname or "sundial.daijro.dev"

    with _Collector() as collector:
        # score=1 makes sundial post counts rather than the report itself, so
        # the vectors never cross the wire. Without it the full report arrives
        # here and the only thing keeping it private is redact() being called --
        # this makes the leak structurally impossible instead of policy-based.
        target = (
            f"{base_url.rstrip('/')}/?auto=1&score=1&post="
            + urllib.parse.quote(f"http://127.0.0.1:{collector.port}/collect", safe="")
        )
        # The report reaches the collector as a public page POSTing to loopback.
        # From Firefox 156 that request is held for a Local Network Access
        # prompt nobody can answer, so exempt sundial's own origin -- the
        # permission state the page can read stays stock ("prompt").
        async with AsyncCamoufox(
            executable_path=str(binary),
            headless=headless,
            os=os_name,
            firefox_user_prefs={"network.lna.skip-domains": host},
            i_know_what_im_doing=True,
        ) as browser:
            context = await browser.new_context()
            await context.add_cookies(
                [{
                    "name": COOKIE_NAME,
                    "value": cookie,
                    "domain": host,
                    "path": "/",
                    "httpOnly": True,
                    "secure": True,
                    "sameSite": "Strict",
                }]
            )
            page = await context.new_page()
            log(f"opening sundial (auto scan) as {os_name}")
            await page.goto(target, wait_until="load", timeout=120_000)
            await _exercise_input(page)

            payload = await asyncio.get_running_loop().run_in_executor(
                None, collector.wait, timeout
            )
            await context.close()

    if payload is None:
        raise TimeoutError(
            f"sundial did not post a report within {timeout:.0f}s. The usual cause is an "
            "expired session cookie (the page silently renders the login form instead of "
            "the suite), or the browser failing to reach the loopback collector."
        )
    if "_parse_error" in payload:
        raise RuntimeError("sundial posted something that was not JSON")
    return payload


async def _exercise_input(page) -> None:
    """Move and click the mouse so sundial's input-pipeline vectors have data.

    The pointer vectors (pointerType, pressure, screen/client offset, down->up
    latency, move cadence) record trusted events for a few seconds after load
    and report "--" (pending) if nothing arrives. This is the same input path a
    user's script takes -- page.mouse through juggler -- so a defect there
    (e.g. an empty pointerType) fails the gate exactly the way it would fail on
    a site. Best-effort: input errors must not abort the scan.
    """
    try:
        vw = await page.evaluate("() => [innerWidth, innerHeight]")
        w, h = (vw or [1280, 720])[:2]
        cx, cy = max(40, w // 3), max(40, h // 3)
        await page.mouse.move(cx - 30, cy - 20)
        for i in range(1, 13):
            await page.mouse.move(cx - 30 + i * 5, cy - 20 + (i % 3) * 2)
            await asyncio.sleep(0.016)
        await page.mouse.down()
        await asyncio.sleep(0.09)
        await page.mouse.up()
        await page.keyboard.press("Shift")
        # Then a burst with no pause between moves. Paced moves look the same
        # on every browser; only a pointer that outruns the compositor shows
        # whether the events are being queued and coalesced the way real input
        # is, which is what ls-pointer-move-rate judges.
        for i in range(1, 61):
            await page.mouse.move(cx + i, cy + (i % 4))
    except Exception as exc:  # noqa: BLE001 - never fail the scan on input
        log(f"input exercise skipped: {exc}", level="WARN")


def seal(report: dict, out: Path) -> Optional[Path]:
    """Optionally keep an encrypted copy of the *full* report for debugging.

    Only written when SUNDIAL_REPORT_AGE_RECIPIENT names an age public key, and
    only readable by whoever holds the matching private key. Without it the full
    report is discarded, because there is nowhere safe to put it: workflow
    artifacts on a public repository are world-readable.
    """
    recipient = os.environ.get("SUNDIAL_REPORT_AGE_RECIPIENT", "").strip()
    if not recipient:
        log("no SUNDIAL_REPORT_AGE_RECIPIENT set -- discarding the full report unencrypted-on-disk")
        return None
    if not run(["which", "age"]).ok:
        log("age is not installed; cannot seal the full report", level="WARN")
        return None
    out.parent.mkdir(parents=True, exist_ok=True)
    plain = out.with_suffix(".tmp.json")
    plain.write_text(json.dumps(report), encoding="utf-8")
    try:
        res = run(["age", "-r", recipient, "-o", str(out), str(plain)])
    finally:
        plain.unlink(missing_ok=True)
    if not res.ok:
        log(f"sealing failed: {res.combined()[-400:]}", level="WARN")
        return None
    log(f"sealed full report -> {out} (only the age key holder can read it)")
    return out


# ---------------------------------------------------------------------------


def _config() -> dict:
    """Scope and thresholds, from ci/sundial.yml."""
    import yaml

    with open(CONFIG_PATH, encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def is_enabled(cfg: Optional[dict] = None) -> bool:
    """Whether CI may run the stealth check at all (ci/sundial.yml: enabled).

    Defaults to False when the key is absent: a check that talks to a private
    suite and posts the answer into a public log should be opt-in, so a config
    that predates the flag does not silently start running.
    """
    return bool((cfg if cfg is not None else _config()).get("enabled", False))


def status(argv: Optional[List[str]] = None) -> int:
    """Print the flag for the workflow, which decides whether to schedule the job."""
    parser = argparse.ArgumentParser(description="report whether the stealth gate is enabled")
    parser.parse_args(argv)
    print("true" if is_enabled() else "false")
    return 0


def gate(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, help="camoufox-bin under test")
    parser.add_argument("--os", dest="os_name", default="linux", choices=["linux", "macos", "windows"])
    parser.add_argument("--headful", action="store_true")
    parser.add_argument("--timeout", type=float, default=300.0)
    parser.add_argument("--evidence-dir", type=Path, default=RESULTS_DIR)
    parser.add_argument(
        "--explain",
        action="store_true",
        help=(
            "print a per-category pass/fail breakdown to the terminal. Local only -- "
            "refused under GITHUB_ACTIONS, where stdout is a public log."
        ),
    )
    parser.add_argument(
        "--allow-full-report",
        action="store_true",
        help=(
            "accept a full report instead of the score. For a deliberate local run under an "
            "account sundial allows one; never in CI, where the account cannot obtain one."
        ),
    )
    args = parser.parse_args(argv)

    if args.explain and os.environ.get("GITHUB_ACTIONS"):
        # Category-level counts are not vectors, but they are a map of where
        # this browser is weak, and a public workflow log is exactly the place
        # that should not carry one. Refused here rather than filtered later,
        # so the flag cannot be turned on in CI by accident.
        raise SystemExit(
            "--explain writes a weakness breakdown to stdout and this is a public "
            "log. Run it locally instead."
        )

    cfg = _config()
    base_url = os.environ.get("SUNDIAL_URL") or cfg.get("url") or DEFAULT_URL
    result = evidence.GateResult(gate="sundial")

    # Checked before the credential is read, and before anything is sent, so a
    # disabled gate cannot reach the deployment even by accident. The workflow
    # also declines to schedule the job; this is the second lock on the same
    # door, for a hand-run or a caller that ignores the first.
    if not is_enabled(cfg):
        # Deliberately writes NO result file, so a hand-run leaves the results
        # directory exactly as a CI run does -- there, the job is not scheduled
        # at all. summarize.py treats every non-pass result as a problem (a suite
        # that did not run has not passed), so emitting a skip here would fail a
        # summary that CI would have passed. And if some caller does require
        # `sundial`, the missing file is the loud failure it should be.
        log(
            "stealth gate disabled in ci/sundial.yml (`enabled: false`) -- not contacting "
            "sundial, and writing no result. See the comment there for what has to be true "
            "before turning it back on."
        )
        return 0

    # The username is not a secret -- it names an account. Only the password
    # needs protecting, so this defaults rather than demanding a second secret.
    username = (os.environ.get("SUNDIAL_USERNAME") or DEFAULT_USERNAME).strip()
    password = os.environ.get("SUNDIAL_AUTOMATION_KEY", "").strip()
    if not username or not password:
        result.note(
            "SUNDIAL_AUTOMATION_KEY is not set. The stealth gate is required by policy, so a "
            "missing credential fails the run rather than skipping it. (SUNDIAL_USERNAME is "
            f"optional and defaults to {DEFAULT_USERNAME!r}.)"
        )
        result.finish(evidence.ERROR).save(args.evidence_dir)
        return 1

    from ._pytest import require_binary

    try:
        binary = args.binary or require_binary()
        cookie = authenticate(base_url, username, password)
        # Before the browser opens sundial at all: confirm the session really is
        # a role that cannot be handed the vectors, rather than trusting that
        # whoever set the secret picked the right key. Held in a local because
        # redact()'s output replaces result.metrics wholesale further down.
        sundial_role = assert_role_cannot_read_vectors(base_url, cookie)
        report = asyncio.run(
            scan(
                binary=binary,
                base_url=base_url,
                cookie=cookie,
                os_name=args.os_name,
                headless=not args.headful,
                timeout=args.timeout,
            )
        )
    except SundialUnavailable as exc:
        # The service is down, so this browser was never measured. Recording a
        # failure would block every merge in the repository on somebody else's
        # outage, and recording a pass would claim a measurement that does not
        # exist. So: a skip, with the reason attached, which the workflow tells
        # ci/summarize.py to tolerate for this suite alone (--allow-skip).
        #
        # Scrubbed like the failure path below -- an exception raised inside
        # urllib can carry the URL that produced it, and for the token route
        # that URL contains the credential.
        result.note(
            scrub(f"stealth check skipped -- {exc}", password)
            + " No stealth measurement was taken for this run."
        )
        result.finish(evidence.SKIP).save(args.evidence_dir)
        return 0
    except Exception as exc:  # noqa: BLE001 -- any failure here is a gate failure
        # Scrubbed: this note goes to the results artifact and the pull request
        # comment, and an exception from deep inside urllib can carry the URL
        # that raised it -- which for the token route contains the credential.
        result.note(scrub(f"{type(exc).__name__}: {exc}", password))
        result.finish(evidence.ERROR).save(args.evidence_dir)
        return 1

    sealed = seal(report, WORK_DIR / "sundial-full-report.age")
    if args.explain:
        # Printed, never recorded: `result` is what reaches the artifact and
        # the pull-request comment, and none of this goes near it.
        for line in explain_buckets(
            report,
            cfg.get("gated_categories") or [],
            cfg.get("ungated_categories") or [],
        ):
            print(line)
    # The plaintext report is dropped here and never referenced again.
    try:
        metrics = redact(
            report,
            cfg.get("gated_categories") or [],
            cfg.get("ungated_categories") or [],
            os_name=args.os_name,
            require_score_mode=not args.allow_full_report,
        )
    except RuntimeError as exc:
        del report
        result.note(str(exc))
        result.finish(evidence.ERROR).save(args.evidence_dir)
        return 1
    del report

    # Deliberately no per-test map. See redact(): a set of opaque ids is still
    # per-vector data, and this gate is judged on the score instead.
    result.metrics = metrics
    # Re-added after the wholesale assignment above: which role the run
    # authenticated as is part of the evidence, not a detail of it. An artifact
    # that does not say makes "the vectors were never served to this session"
    # unverifiable after the fact, which is most of the point of recording it.
    result.metrics["sundial_role"] = sundial_role
    if sealed:
        result.artifacts.append(sealed.name)

    metrics = result.metrics
    # This string reaches the job summary and the pull request. Grade and counts
    # only -- no category, no vector, no value. The keys are the ones on
    # _PUBLISHABLE; read them through it so that renaming one breaks here rather
    # than silently rendering a zero.
    result.note(
        f"grade {metrics['grade']} -- {metrics['checks_passed']}/{metrics['checks_total']} "
        f"in-scope checks passed ({metrics['pass_rate'] * 100:.1f}%). "
        f"{metrics['out_of_scope_failed']} out-of-scope check(s) failed; those are measured "
        "but not gated, because Camoufox does not claim them."
    )

    floor = float(cfg.get("min_pass_rate", 0) or 0)
    status = evidence.PASS
    # Absolute rules, independent of the baseline: a run that scores badly fails
    # even if the previous release scored just as badly.
    violations: List[str] = []
    if metrics["checks_total"] == 0:
        result.note("no gated vectors were scored -- treating as a failure, not a pass")
        violations.append(
            "no gated vectors were scored; the scan produced a report with nothing in scope"
        )
        status = evidence.FAIL
    elif metrics.get("unknown_category_checks"):
        n = metrics["unknown_category_checks"]
        result.note(
            f"{n} scored check(s) are in a category ci/sundial.yml does not name, so "
            "nobody has decided whether Camoufox claims them"
        )
        violations.append(
            f"{n} scored check(s) fell outside both category lists in ci/sundial.yml. "
            "sundial has grown a section; add it to gated_categories or "
            "ungated_categories. Failing rather than ignoring it, because ignoring it "
            "is a stealth blind spot that reads as a pass."
        )
        status = evidence.FAIL
    elif metrics["pass_rate"] < floor:
        result.note(f"pass rate {metrics['pass_rate']:.3f} is below the policy floor {floor}")
        violations.append(
            f"stealth pass rate {metrics['pass_rate']:.3f} is below the policy floor {floor}"
        )
        status = evidence.FAIL
    result.metrics["policy_violations"] = violations
    _assert_publishable(result.metrics)

    result.finish(status).save(args.evidence_dir)
    # This reports the floor only. Per-test regression against a stored
    # baseline is the auto-update harness's job, outside this repository.
    return 0 if status == evidence.PASS else 1


def waive(argv: Optional[List[str]] = None) -> int:
    """Print a waiver stanza for a vector, without naming the vector in it.

    The file this is pasted into belongs to the auto-update harness and is not
    in this repository; the command is here because computing the opaque id
    needs the same salt the gate uses.
    """
    parser = argparse.ArgumentParser(description="compute a waiver entry for a sundial vector")
    parser.add_argument("--key", required=True, help="the vector key, as it appears in the report")
    parser.add_argument("--reason", required=True, help="why Camoufox does not claim this")
    parser.add_argument("--days", type=int, default=90, help="waiver lifetime (default 90)")
    args = parser.parse_args(argv)

    print("\nAdd under gates.sundial.waivers in the auto-update harness's policy file\n"
          "(that file is not part of this repository):\n")
    print(f"  - id: {opaque_id(args.key)}")
    print(f"    reason: {args.reason}")
    print(f"    expires: {date.today() + timedelta(days=args.days)}")
    print("\n(The key itself is deliberately not written to the file.)\n")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "waive":
        return waive(argv[1:])
    if argv and argv[0] == "status":
        return status(argv[1:])
    return gate(argv)


if __name__ == "__main__":
    sys.exit(main())
